//
//  SceneDelegate.h
//  AyrsDemo
//
//  Created by Senyao Lian on 2022/8/16.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

