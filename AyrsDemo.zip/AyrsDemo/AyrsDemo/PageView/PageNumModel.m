//
//  PageNumModel.m
//  AyrsDemo
//
//  Created by Senyao Lian on 2022/8/17.
//

#import "PageNumModel.h"

@implementation PageNumModel

@end
