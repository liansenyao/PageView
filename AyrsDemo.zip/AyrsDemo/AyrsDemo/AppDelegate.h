//
//  AppDelegate.h
//  AyrsDemo
//
//  Created by Senyao Lian on 2022/8/16.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

